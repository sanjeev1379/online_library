<?php

$con=mysqli_connect("localhost", "1028045" ,"gate2017" ,"1028045");

if(mysqli_connect_errno()){

  echo "Field to connect to Mysql:" .mysqli_connect_error();

}


?>
