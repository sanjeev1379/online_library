<?php

include("includes/db.php");

?>

<!DOCTYPE Html>
<html lang="en">
<head>
  <title>Library | Email</title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width-device-width scale=1.0" />
  <link rel="shortcut icon" href="image/user.png" ></link>
  <link rel="stylesheet" href="css/style.css" ></link>
  <link rel="stylesheet" href="css/circle-hover.css" ></link>
  <link rel="stylesheet" href="css/bootstrap.min.css" ></link>
  <script type="text/javascript" src="js/script.js" ></script>
  <script type="text/javascript" src="js/jquery.min.js" ></script>
  <script type="text/javascript" src="js/bootstrap.min.js" ></script>
  <script type="text/javascript" src="js/jquery.kwicks-1.5.1.js"></script>
</head>
<body>
  <div class="container-fluid" id="bg_1">
    <div class="container" id="bg_1">
      <center>
           <a href="#"><img src="image/logo.png" style="border-radius:50%;margin-top:3.4%;" class="img-responsive" width="12%" height="12%" /></a>
           <p id="para">Departmental Library</p>
           <p id="para_id">Department of Computer Science & Engineering (CSE)</p>
      </center>
    </div>
    <div class="container"  id="bg_1">
      <center><div class="modal-content" style="width:50%;" id="bg_form">
        <p id="middle">REMEMBER !!</p>
        <p id="middle_id">This action is used only to recover your forgetten username & password<br />when you enter the valid address sysyem will send you an email that<br /> contains the username and password otherwise sustem will redirected to<br /> the HOME automatically !!</p>
      <div class="modal-body">
        <form role="form" method="post" action="" enctype="multiplepart/form">
            <div class="form-group">
              <span class='label label-info' id="n">  Enter Valid Email address </span>
              <input type="email" name="consumer" class="form-control" placeholder="Enter Email..." style="width:70%;"  />
            </div>
      </div>
      <div class="modal-footer">
        <input type="submit" name="submit_feedback" id="bt" class="btn btn-primary btn-block" value="Submit"  style="width:130%; margin-left:-15%;"/>
      </div>
      </form>
    </div></center>
  </div>
  <center>
         <p id="footer_p">Devloped By</p>
         <p id="footer_id">B.C.E Bhagalpur</p>
         <p id="footer_id">spring - 2010 : Reg # 11022152 : cse</p>
  </center>
</div>
</body>
</html>
