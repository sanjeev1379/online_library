<?php
$host='localhost';
$user='1028045';
$pass='gate2017';
$dbname='1028045';
@mysql_connect($host,$user,$pass);
@mysql_select_db($dbname);
?>
